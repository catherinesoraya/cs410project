import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.StringTokenizer;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;


/**
 * This class is application hooked up to a database to create Tasks and DESTROY THEM! 
 * 
 * @author Catherine Yazdanpour, Danny Chavez 
 */
public class TaskDestroyer {

	public static void main(String[] args) throws SQLException, ClassNotFoundException, JSchException {

		if(args.length < 5 || args.length > 5) {
			System.out.println("Usage: java TaskDestroyer <BroncoUserid> <BroncoPassword> <sandboxUserId> <sandbox password> <yourportnumber>");
			System.exit(0);
		}

		Connection con = null;
		Session session = null;
		
		try
		{
			String strSshUser = args[0];                  // SSH loging username
			String strSshPassword = args[1];                   // SSH login password
			String strSshHost = "onyx.boisestate.edu";          // hostname or ip or SSH server
			int nSshPort = 22;                                    // remote SSH host port number
			String strRemoteHost = "localhost";  // hostname or ip of your database server
			int nLocalPort = 3367;  // local port number use to bind SSH tunnel

			String strDbUser = args[2];                   // database loging username
			String strDbPassword = args[3];                    // database login password
			int nRemotePort = Integer.parseInt(args[4]); // remote port number of your database 

			/*
			 * STEP 0
			 * CREATE a SSH session to ONYX
			 * 
			 * */
			session = TaskDestroyer.doSshTunnel(strSshUser, strSshPassword, strSshHost, nSshPort, strRemoteHost, nLocalPort, nRemotePort);


			/*
			 * STEP 1 and 2
			 * LOAD the Database DRIVER and obtain a CONNECTION
			 * 
			 * */
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:"+nLocalPort, strDbUser, strDbPassword);
			con.setAutoCommit(false);
			
			createSchema(con);
			
			System.out.println("Connection successful!\n\n");

			ScanMan(con);

		}
		catch( SQLException e )
		{
			System.out.println(e.getMessage());
			con.rollback(); // In case of any exception, we roll back to the database state we had before starting this transaction
		}
		finally{

			/*
			 * STEP 5
			 * CLOSE CONNECTION AND SSH SESSION
			 * 
			 * */

			con.setAutoCommit(true); // restore dafault mode
			con.close();
			session.disconnect();
		}
	}	
	
	/**
	 * Create the schema for the User database
	 */
	public static void createSchema(Connection con) {

		Statement stmt;
		try {
			stmt = con.createStatement();
			
			String createDB = " CREATE DATABASE IF NOT EXISTS TaskMan";
			stmt.execute(createDB);
			
			String useDB = "USE TaskMan";
			stmt.execute(useDB);
			
			String drop = "DROP TABLE Task";
			stmt.execute(drop);
			
			String createTask ="CREATE TABLE IF NOT EXISTS Task (taskId int NOT NULL AUTO_INCREMENT, label VARCHAR(64) NOT NULL, "
					+"creationDate DATE, dueDate DATE, tag VARCHAR(128), status VARCHAR(20), PRIMARY KEY (taskId))"; 

			stmt.execute(createTask);

		} catch (SQLException e) {
						
			System.out.println("SQL exception ocurred while creating the schema");
			e.printStackTrace();
			System.exit(0);
		}		
	}

	private static void ScanMan(Connection con) throws SQLException {

		System.out.println("Welcome to the Task Destroyer.");

		Scanner scan = new Scanner(System.in);

		String response = scan.nextLine();

		while(!response.equals("exit")){

			HandleResponse(response, con);

			con.commit(); //transaction block ends

			System.out.println("Transaction done!");

			response = scan.nextLine();

		}
		scan.close();
	}

	private static void HandleResponse(String response, Connection con) {

		Statement stmt;

		String SqlStmt = "";
		ResultSet rs;

		StringTokenizer tok = new StringTokenizer(response, ",");
	
		while(tok.hasMoreTokens()) {
			String command = tok.nextToken();
			StringTokenizer tok2 = new StringTokenizer(command, " ");
			String commandWord = tok2.nextToken();
			try {
				stmt = con.createStatement();
								
				if(commandWord.equals("active")) {

					String tag = "";
					if(tok2.hasMoreTokens()) {
						tag = tok2.nextToken();
					}
					
					if(tag.isEmpty()) {
						SqlStmt = "SELECT * FROM Task WHERE status = 'active'";
					}else {
						SqlStmt = "SELECT * FROM Task WHERE status = 'active' AND tag LIKE '%"+tag+"%'";		
					}
					rs = stmt.executeQuery(SqlStmt);
					System.out.println(PrintResults(rs));

				}else if(commandWord.equals("add")) {

					String taskLabel = "";
					while(tok2.hasMoreTokens()) {
						taskLabel += tok2.nextToken();
						if(tok2.hasMoreTokens()) {
							taskLabel+= " ";
						}
					}
					if(taskLabel.isEmpty()) {
						System.out.println("Usage: add <task label>");
						break;
					}

					SqlStmt = "INSERT INTO Task (label, creationDate, status) VALUES ('"+taskLabel+"', CURDATE(), 'active')";
					stmt.execute(SqlStmt);

					SqlStmt = "SELECT taskId FROM Task WHERE label = '"+taskLabel+"'";
					rs = stmt.executeQuery(SqlStmt);
					System.out.println("task ID: "+ PrintResults(rs));
					
				} else if(commandWord.equals("due")) {

					String next = tok2.nextToken();
					if(next != null) {

						if(next.equals("soon")) {
							SqlStmt = "SELECT * FROM Task WHERE dueDate <= DATE_ADD(CURDATE(), INTERVAL 3 DAY)";
							rs = stmt.executeQuery(SqlStmt);
							System.out.println(PrintResults(rs));
						} else if (next.equals("today")) {
							SqlStmt = "SELECT * FROM Task WHERE dueDate = CURDATE()";
							rs = stmt.executeQuery(SqlStmt);
							System.out.println(PrintResults(rs));
						} else {

							try {
								int taskId = Integer.parseInt(next);
								String date = tok2.nextToken();							
								SqlStmt = "UPDATE Task SET dueDate = '"+date+"' WHERE taskId = "+taskId;
								stmt.executeUpdate(SqlStmt);
							} catch (NumberFormatException nfe) {
								System.out.println("Usage: due soon | due today | due <task id> <date>");
							} 
						}
					}
				}else if(commandWord.equals("tag")) {
	
					int Id = Integer.parseInt(tok2.nextToken());
					String next; //= tok2.nextToken();
					
					SqlStmt = "SELECT tag FROM Task WHERE taskId = "+ Id;
					
					rs = stmt.executeQuery(SqlStmt);
					
					boolean nextRs = rs.next();
					String oldTag = "";
					if(nextRs) {
						oldTag = rs.getString("tag");
					}
					
					if(oldTag!= null && !oldTag.equals("null "))
						SqlStmt = "UPDATE Task SET tag = '" + oldTag+" " ;
					else
						SqlStmt = "UPDATE Task SET tag = '";
					
					
					while(tok2.hasMoreTokens()) {					
						next = tok2.nextToken();
						if(!tok2.hasMoreTokens()) {
							SqlStmt += next;
						}else {
							SqlStmt += next + " ";
						}
					}
					
					SqlStmt += "' WHERE taskId = " + Id;

					stmt.executeUpdate(SqlStmt);
					
				}else if(commandWord.equals("finish")) {
		
					int Id = Integer.parseInt(tok2.nextToken());
					
					SqlStmt = "UPDATE Task SET status = 'completed' WHERE taskId = " + Id;
					stmt.executeUpdate(SqlStmt);
					
				}else if(commandWord.equals("cancel")) {
				
					int Id = Integer.parseInt(tok2.nextToken());
					
					SqlStmt = "UPDATE Task SET status = 'canceled' WHERE taskId = " + Id;
					stmt.executeUpdate(SqlStmt);
					
				}else if(commandWord.equals("show")) {
				
					int Id = Integer.parseInt(tok2.nextToken());
					SqlStmt = "SELECT * FROM Task WHERE taskId = " + Id;
					
					rs = stmt.executeQuery(SqlStmt);
					
					System.out.println(PrintResults(rs));
				}else if(commandWord.equals("completed")) {
				
					String tag = tok2.nextToken();
					SqlStmt = "SELECT taskId, label FROM Task WHERE status = 'completed' AND tag LIKE '%"+tag+"%'";		
					rs = stmt.executeQuery(SqlStmt);
					System.out.println(PrintResults(rs));
					
				}else if(commandWord.equals("overdue")) {
					
					SqlStmt = "SELECT taskId, label FROM Task WHERE status = 'active' AND dueDate < CURDATE()";		
					rs = stmt.executeQuery(SqlStmt);
					System.out.println(PrintResults(rs));				
				}else if(commandWord.equals("rename")) {
				
					int id = Integer.parseInt(tok2.nextToken());
					String taskLabel = "";
					while(tok2.hasMoreTokens()) {
						taskLabel += tok2.nextToken() + " ";
					}
					if(taskLabel.isEmpty()) {
						System.out.println("Usage: rename <taskId> <task label>");
						break;
					}
					
					SqlStmt = "UPDATE Task SET label = '"+taskLabel+"' WHERE taskId = " +id;		
					stmt.executeUpdate(SqlStmt);
						
				}else if(commandWord.equals("search")) {
					
					String keyWord = tok2.nextToken();
					SqlStmt = "SELECT * FROM Task WHERE label LIKE '%"+keyWord+"%'";		
					rs = stmt.executeQuery(SqlStmt);
					System.out.println(PrintResults(rs));					
				}
				
			} catch (SQLException e) {
			} catch(NoSuchElementException e) {
				System.out.println("command syntax error");
			}


		}
	}

	private static String PrintResults(ResultSet resultSet) throws SQLException{
		ResultSetMetaData rsmd = resultSet.getMetaData();
		String out = "";
		int columnsNumber = rsmd.getColumnCount();
		
		while (resultSet.next()) {
			for (int i = 1; i <= columnsNumber; i++) {
				if (i > 1) out+="\t";
				String columnValue = resultSet.getString(i);
				out += rsmd.getColumnName(i)+": "+ columnValue;
			}
			out += " ";
		}
		return out;
	}

	private static Session doSshTunnel( String strSshUser, String strSshPassword, String strSshHost, int nSshPort, String strRemoteHost, int nLocalPort, int nRemotePort ) throws JSchException
	{
		/*This is one of the available choices to connect to mysql
		 * If you think you know another way, you can go ahead*/

		final JSch jsch = new JSch();
		java.util.Properties configuration = new java.util.Properties();
		configuration.put("StrictHostKeyChecking", "no");

		Session session = jsch.getSession( strSshUser, strSshHost, 22 );
		session.setPassword( strSshPassword );

		session.setConfig(configuration);
		session.connect();
		session.setPortForwardingL(nLocalPort, strRemoteHost, nRemotePort);
		return session;
	}

}